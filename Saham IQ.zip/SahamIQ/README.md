Saham IQ 
